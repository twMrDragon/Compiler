x = list(range(7))
print(x[0])
print(x[6])

