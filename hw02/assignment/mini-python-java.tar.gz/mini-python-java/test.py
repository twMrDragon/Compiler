print(41+1)
