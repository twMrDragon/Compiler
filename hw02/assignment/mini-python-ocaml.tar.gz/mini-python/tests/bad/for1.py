for x in 42:
    print(x)
