print(1 + "foo")
