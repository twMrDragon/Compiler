row = [1, 2, 3]
badmatrix = [row, row, row]
print(badmatrix)
badmatrix[1][1] = 42
print(badmatrix)
