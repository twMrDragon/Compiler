print(len(1))
