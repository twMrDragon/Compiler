x && y

