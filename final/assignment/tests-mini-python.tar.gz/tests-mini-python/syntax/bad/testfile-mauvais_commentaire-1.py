truc # Ceci est un commentaire
qui continue sur la deuxieme ligne !!

