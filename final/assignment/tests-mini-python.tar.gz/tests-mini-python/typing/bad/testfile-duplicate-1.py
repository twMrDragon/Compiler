def f(x,x):
    return x
print(0)



